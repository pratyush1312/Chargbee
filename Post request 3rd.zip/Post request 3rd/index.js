
headers: {
  'Access-Control-Allow-Origin': '*'
  }
const chargebeeApiUrl = 'https://solutions-int-test.chargebee.com/api/v2/customers';
const chargebeeApiKey = 'test_tVAoLET8SehnfQ8YNZsrm3MDcdXfAQu4e';

const form = document.getElementById('customer-form');

form.addEventListener('submit', event => {
  event.preventDefault();

  const firstName = document.getElementById('first-name').value;
  const lastName = document.getElementById('last-name').value;
  const email = document.getElementById('email').value;
  const cardNumber = document.getElementById('card-number').value;
  const expiryMonth = document.getElementById('expiry-month').value;
  const expiryYear = document.getElementById('expiry-year').value;
  const cvv = document.getElementById('cvv').value;
  const billingZip = document.getElementById('billing-zip').value;

  const requestBody = {
    customer: {
      first_name: firstName,
      last_name: lastName,
      email: email,
      card: {
        number: cardNumber,
        expiry_month: expiryMonth,
        expiry_year: expiryYear,
        cvv: cvv,
        billing_zip: billingZip
      }
    }
  };

  fetch(chargebeeApiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Basic ' + btoa(chargebeeApiKey + ':')
    },
    body: JSON.stringify(requestBody)
  })
  .then(response => response.json())
  .then(data => {
    //console.log(data);
    const customerId = data.customer.id;

    // Creating subscription record
    const subscriptionRequestBody = {
      subscription: {
        plan_id: 'basic-plan',
        auto_collection: 'on',
        customer_id: customerId
      }
    };

    fetch('https://solutions-int-test.chargebee.com/api/v2/subscriptions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Basic ' + btoa(chargebeeApiKey + ':')
      },
      body: JSON.stringify(subscriptionRequestBody)
    })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error(error));
  })
  .catch(error => console.error(error));
});